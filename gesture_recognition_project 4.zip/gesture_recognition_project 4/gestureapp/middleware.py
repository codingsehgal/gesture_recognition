from typing import Any
import cv2
import mediapipe as mp
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
import base64
import json


mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils

class CameraMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        self.holistic = mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5)

    def __call__(self, request):
        if request.path == '/open_camera':
            # Code for video capture and Mediapipe processing
            cap = cv2.VideoCapture(0)
            ret, frame = cap.read()
            image, results = self.mediapipe_detection(frame)
            self.draw_styled_landmarks(image, results)

            # Convert image to bytes (you might need to adjust this depending on your needs)
            _, img_encoded = cv2.imencode('.png', image)
            img_bytes = img_encoded.tobytes()

            # Add the processed image bytes to the response
            response = HttpResponse(content_type='image/png')
            response.write(img_bytes)

            # Release resources
            cap.release()

            return response
        return self.get_response(request)

    def mediapipe_detection(self, image):
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image.flags.writeable = False
        results = self.holistic.process(image)
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        return image, results
    
    def draw_landmarks(image, results):
        face_connections = [
            (10, 338), (338, 297), (297, 332), (332, 284), (284, 251), (251, 389),
            (389, 356), (356, 454), (454, 323), (323, 361), (361, 288), (288, 397),
            # Add more connections as needed
        ]

        for connection in face_connections:
            mp_drawing.draw_landmarks(
                image, results.face_landmarks, mp_drawing.DrawingSpec(color=(80, 110, 10), thickness=1, circle_radius=1),
                mp_drawing.DrawingSpec(color=(80, 256, 121), thickness=1, circle_radius=1),
                connection_points=connection
            )
        mp_drawing.draw_landmarks(image, results.face_landmarks, mp_holistic.FACE_CONNECTIONS) # Draw face connections
        mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS) # Draw pose connections
        mp_drawing.draw_landmarks(image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS) # Draw left hand connections
        mp_drawing.draw_landmarks(image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS) # Draw right hand connections

    def draw_styled_landmarks(self, image, results):
        # Draw face connections manually
        face_connections = [
            (10, 338), (338, 297), (297, 332), (332, 284), (284, 251), (251, 389),
            (389, 356), (356, 454), (454, 323), (323, 361), (361, 288), (288, 397),
            # Add more connections as needed
        ]

        for connection in face_connections:
            point1 = (
                int(results.face_landmarks.landmark[connection[0]].x * image.shape[1]),
                int(results.face_landmarks.landmark[connection[0]].y * image.shape[0])
            )
            point2 = (
                int(results.face_landmarks.landmark[connection[1]].x * image.shape[1]),
                int(results.face_landmarks.landmark[connection[1]].y * image.shape[0])
            )
            cv2.line(image, point1, point2, (80, 110, 10), 1)

        # Draw other landmarks as needed
        mp_drawing.draw_landmarks(
            image, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS,
            mp_drawing.DrawingSpec(color=(80, 22, 10), thickness=2, circle_radius=4),
            mp_drawing.DrawingSpec(color=(80, 44, 121), thickness=2, circle_radius=2)
        )

        mp_drawing.draw_landmarks(
            image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
            mp_drawing.DrawingSpec(color=(121, 22, 76), thickness=2, circle_radius=4),
            mp_drawing.DrawingSpec(color=(121, 44, 250), thickness=2, circle_radius=2)
        )

        mp_drawing.draw_landmarks(
            image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
            mp_drawing.DrawingSpec(color=(245, 117, 66), thickness=2, circle_radius=4),
            mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=2)
        )